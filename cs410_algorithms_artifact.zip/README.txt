CS-410 Algorithms Artifact - Binary to C++ Conversion

This project contains:
- The original binary file (assignment6_1.o)
- The reverse-engineered and enhanced C++ source code
- Description of enhancements made for CS-499 Capstone

Enhancements:
- Simplified logic using cleaner conditional structures
- Added input validation
- Reduced unnecessary complexity
