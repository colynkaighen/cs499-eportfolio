#include <iostream>

int processInput(int input) {
    if (input < 0) {
        return -1;
    } else if (input == 0) {
        return 0;
    } else if (input % 2 == 0) {
        return input * 2;
    } else {
        return input + 1;
    }
}

int main() {
    int userInput;
    std::cout << "Enter an integer: ";
    std::cin >> userInput;

    int result = processInput(userInput);
    std::cout << "Result: " << result << std::endl;
    return 0;
}
